// miniprogram_xyxd/pages/temporaryInput/userInput/userInput.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    status: null,
    openid: null,
    majors: null,
    colleges: null,
    name:null,
    sex: null,
    campus: null,
    sexColumns: ['男', '女'],
    campusColumns: ['松山湖校区', '莞城校区'],
    collegeColumns: ["马克思主义学院 ", "机械工程学院", "电子工程与智能化学院 ", "计算机科学与技术学院 ", "生态环境与建筑工程学院 ", "经济与管理学院 ", "文学与传媒学院", "教育学院(师范学院) ", "化学工程与能源技术学院 ", "粤台产业科技学院 ", "粤港机器人学院 ", "国际学院 ", "网络空间安全学院", "材料科学与工程学院"],
    show: false,
    show_campus: false,
    show_college: false,
  },
  submit(event) {
    console.log(event);
    var person = {
      name:event.detail.value.name,
      id: event.detail.value.id,
      major: event.detail.value.major,
      introduction: event.detail.value.introduction,
      sex: this.data.sex,
      campus: this.data.campus,
      college: this.data.college

    }
    // 直接使用person
    console.log(person);
  },
  showPopup(event) {
    console.log(event);
    var show = event.target.id;
    if (show == "sex")
      this.setData({
        show: true
      });
    if (show == "campus")
      this.setData({
        show_campus: true
      });
    if (show == "college")
      this.setData({
        show_college: true
      });
  },

  onClose(event) {
    var show = event.target.id;
    if (show == "sex")
      this.setData({
        show: false
      });
    if (show == "campus")
      this.setData({
        show_campus: false
      });
    if (show == "college")
      this.setData({
        show_college: false
      });
  },

  onConfirm(event) {
    // const { picker, value, index } = event.detail;
    console.log(event);
    var show = event.target.id;
    if (show == "sex")
      this.setData({
        sex: event.detail.value,
      });
    if (show == "campus")
      this.setData({
        campus: event.detail.value,
      });
    if (show == "college")
      this.setData({
        college: event.detail.value,
      });
    this.onClose(event)

  },

  onCancel(event) {
    // console.log(event);
    this.onClose(event);
    // this.setData({
    //   show: false
    // });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this
    wx.getStorage({
        key: 'colleges',
        success: function(res) {
          // 测试，可以删掉 
          //var lenth = that.data.majors['lenth']
          var lenth = res.data['lenth']
          for (var i = 1; i <= lenth; i++) {
            console.log (res.data[i])
        }
        that.setData({
          status: options.status,
          colleges: res.data
        })
      },
      fail: function(res) {
        //console.log('11云函数')
        wx.cloud.callFunction({
          name: 'getAllInstitute',
          success: res => {
            console.log('云函数' + res.result.data[0]['1'])
            wx.setStorage({
              key: 'colleges',
              data: res.result.data[0]
            })
            that.setData({
              colleges: res.result.data[0]
            })
            //that.data.majors = res.result.data[0]
          }
        })
      }
    })

},

/**
 * 生命周期函数--监听页面初次渲染完成
 */
onReady: function() {
  var that = this
  //that.data.status = options.status
  wx.getStorage({
    key: 'majors',
    success: function(res) {
      that.setData({
        majors: res.data
      })
    }
  })
  wx.getStorage({
    key: 'openid',
    success: function(res) {
      that.data.openid = res.data.openid
      console.log('缓存' + that.data.openid)
    }
  })


},

/**
 * 生命周期函数--监听页面显示
 */
onShow: function() {

},

/**
 * 生命周期函数--监听页面隐藏
 */
onHide: function() {

},

/**
 * 生命周期函数--监听页面卸载
 */
onUnload: function() {

},

/**
 * 页面相关事件处理函数--监听用户下拉动作
 */
onPullDownRefresh: function() {

},

/**
 * 页面上拉触底事件的处理函数
 */
onReachBottom: function() {

},

/**
 * 用户点击右上角分享
 */
onShareAppMessage: function() {

}
})